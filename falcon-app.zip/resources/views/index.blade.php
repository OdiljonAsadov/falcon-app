
@extends('layout.app')

@section('content')
    <h1>Добро пожаловать</h1>
@endsection
