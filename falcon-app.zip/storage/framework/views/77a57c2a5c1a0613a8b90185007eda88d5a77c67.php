
<?php $__env->startSection('content'); ?>
    

<div class="main-content">
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="container">
        
        <div class="img-container">
            <div class="row justify-content-between">
                    <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-4 col-sm-12"><img src="<?php echo e($category->image_1); ?>" alt="9" style="width: 250px; height: 250px; object-fit: cover;" class="img-fluid"></div>
                    <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-4 col-sm-12"><img src="<?php echo e($category->image_2); ?>" alt="9" style="width: 250px; height: 250px; object-fit: cover;" class="img-fluid"></div>
                    <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-4 col-sm-12"><img src="<?php echo e($category->image_3); ?>" alt="9" style="width: 250px; height: 250px; object-fit: cover;" class="img-fluid"></div>
                </div>
            </div>
            <div>
                <h2 class="title">UZ</h2>
                <p><?php echo $category->summernote_uz; ?></p>
            </div>

            <div>
                <h2 class="title">RU</h2>
                <p><?php echo $category->summernote_ru; ?></p>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\falcon-app\resources\views/show.blade.php ENDPATH**/ ?>