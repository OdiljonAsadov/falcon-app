
<?php $__env->startSection('content'); ?>
    <div class="card card-primary col-md-9" style="margin-left: 15vw; margin-top: -2vh;">
        <!-- /.card-header -->
        <!-- form start -->
        <?php $__currentLoopData = $info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
        
        <form action="/information/edit/<?php echo e($inf->id); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo e(csrf_field()); ?>

            <div class="card-body">
                <div class="form-group">
                    <label for="exampleInputEmail1">Title Uz</label>
                    <input type="text" class="form-control" id="exampleInputEmail1" name="title_uz" required value="<?php echo e($inf->title_uz); ?>">
                </div>
                <div class="form-group">
                    <label for="exampleInputEmail1">Title Ru</label>
                    <input type="text" class="form-control" id="exampleInputEmail1" name="title_ru" required value="<?php echo e($inf->title_ru); ?>">
                </div>
            
                <div class="form-group">
                    <label for="exampleInputEmail1">Image_1</label>
                    <input type="file" class="form-control" id="exampleInputEmail1" name="image_1" value="<?php echo e($inf->image_1); ?> required >
                </div>
                <div class="form-group">
                    <label for="exampleInputEmail1">Image_2</label>
                    <input type="file" class="form-control" id="exampleInputEmail1" name="image_2" value="<?php echo e($inf->image_2); ?> required >
                </div>
            
                <div class="form-group">
                    <label for="exampleInputEmail1">Image_3</label>
                    <input type="file" class="form-control" id="exampleInputEmail1" name="image_3" value="<?php echo e($inf->image_3); ?> required >
                </div>
                <div class="form-group">
                    <label for="exampleInputEmail1">Summernote_UZ</label>
                    <textarea class="sum" id="summernote2" name="summernote_uz" >
                       <?php echo e($inf->summernote_uz); ?>

                    </textarea>
                </div>
           
                <div class="form-group">
                    <label for="exampleInputEmail1">Summernote_RU</label>
                    <textarea class="sum" id="summernote1" name="summernote_ru">
                        <?php echo e($inf->summernote_ru); ?>

                    </textarea>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <button type="submit" class="btn btn-primary" style="margin: 10px 10px 15px 20px">Добавить</button>
               
            </div>
        </form>
    </div>
    <script>
        $('#summernote1').summernote({
            height: 300
        });
        $('#summernote2').summernote({
            height: 300
        });
        $(document).ready(function() {
            $('.sum').summernote({
                height: 300
            });
        });
    </script>
<?php $__env->stopSection(); ?>
    

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\falcon-app\resources\views/information/edit.blade.php ENDPATH**/ ?>