
<?php $__env->startSection('content'); ?>
    <h1>Категории</h1>
    <a href="/category/add" class="btn btn-success" style="margin-right: 20px">Добавить категорию</a>
    

    <table class="table text-center">
        <tr>
            <th>ID</th>
            <th>Title Uz</th>
            <th>Title Ru</th>
           
        </tr>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($category->id); ?></td>
                <td><?php echo e($category->title_uz); ?></td>
                <td><?php echo e($category->title_ru); ?></td>
                
               
                <td>
                    <a href="/category/edit/<?php echo e($category->id); ?>" class="btn btn-primary">Редактировать</a>
                    <a href="/category/delete/<?php echo e($category->id); ?>" class="btn btn-danger">Удалить</a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\falcon-app\resources\views/category/index.blade.php ENDPATH**/ ?>