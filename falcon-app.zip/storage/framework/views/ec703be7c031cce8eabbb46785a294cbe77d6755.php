
<?php $__env->startSection('content'); ?>
    <div class="card card-primary col-md-6" style="margin-left: 15vw; margin-top: -2vh; height: 78vh">
        <div class="card-header" style="width: 102.5%; margin-left: -7.5px">
            <h3 class="card-title">Добавить продукт</h3>
        </div>
        <!-- /.card-header -->
        <!-- form start -->
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
       
        <form action="/category/edit/<?php echo e($category->id); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo e(csrf_field()); ?>

            <div class="card-body">
                <div class="form-group">
                    <label for="exampleInputEmail1">Title Uz</label>
                    <input type="text" class="form-control" id="exampleInputEmail1" name="title_uz" required value="<?php echo e($category->title_uz); ?>">
                </div>
                <div class="form-group">
                    <label for="exampleInputEmail1">Title Ru</label>
                    <input type="text" class="form-control" id="exampleInputEmail1" name="title_ru" required value="<?php echo e($category->title_ru); ?>">
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <button type="submit" class="btn btn-primary" style="margin: 10px 10px 15px 20px">Добавить</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\falcon-app\resources\views/category/edit.blade.php ENDPATH**/ ?>