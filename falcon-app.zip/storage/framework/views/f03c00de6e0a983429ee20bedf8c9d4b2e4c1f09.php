<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css"
        integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous" />
    <link
        href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100;0,200;0,300;0,400;0,600;0,700;0,800;1,400&display=swap"
        rel="stylesheet">
    <!-- anime -->
    <link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" />
    <link rel="stylesheet" href="<?php echo e(asset('css/about.css')); ?>">
    <title>O нас</title>
</head>

<body>
    <!-- navbar -->
    <div class="nawbar container-fluid">
        <nav class="navbar navbar-expand-lg">
            <div class="container-fluid">
                <a class="navbar-brand" href="/"><img src="../images/Logo.svg" alt="logo" class="img-fluid"
                        style="height: 50px;"></a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                    data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                    aria-expanded="false" aria-label="Toggle navigation">
                    <i class="far fa-bars"></i>
                </button>
                <div class="collapse navbar-collapse right-nav" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0 w-100 justify-content-between">
                        <li class="nav-item">
                            <a class="nav-link" aria-current="page" href="/?language=<?php echo e(Request::get('language')); ?>"><?php echo e(__('home')); ?></a>
                        </li>
                        <li class="nav-item">
                            <div class="dropdown">
                                <button class="btn dropdown-toggle" style="font-size: 17px; font-weight: 700; line-height: 30px; color: #999;" type="button" id="dropdownMenuButton1"
                                    data-bs-toggle="dropdown" aria-expanded="false">
                                    Катигории
                                </button>
                                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <ul>
                                                <li><a class="dropdown-item" href="/information/show/1"> <?php echo e(__('category1')); ?> </a></li>
                                                <li><a class="dropdown-item" href="/information/show/1"> <?php echo e(__('category2')); ?> </a></li>
                                                <li><a class="dropdown-item" href="/information/show/1"> <?php echo e(__('category3')); ?> </a></li>
                                                <li><a class="dropdown-item" href="/information/show/1"> <?php echo e(__('category4')); ?> </a></li>
                                                <li><a class="dropdown-item" href="/information/show/1"> <?php echo e(__('category5')); ?></a></li>
                                                <li><a class="dropdown-item" href="/information/show/1"> <?php echo e(__('category6')); ?> </a></li>
                                                <li><a class="dropdown-item" href="/information/show/1"> <?php echo e(__('category7')); ?> </a></li>
                                                <li><a class="dropdown-item" href="/information/show/1"> <?php echo e(__('category8')); ?> </a></li>
                                                <li><a class="dropdown-item" href="/information/show/1"> <?php echo e(__('category9')); ?> </a></li>
                                                <li><a class="dropdown-item" href="/information/show/1"> <?php echo e(__('category10')); ?> </a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </li>
                        
                        
                        <li class="nav-item"><a class="nav-link active" href="/about?language=<?php echo e(Request::get('language')); ?>"><?php echo e(__('about')); ?></a></li>
                        <li class="nav-item">
                            <a class="nav-link" href="/servise?language=<?php echo e(Request::get('language')); ?>"><?php echo e(__('serves')); ?></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="/gallery?language=<?php echo e(Request::get('language')); ?>"><?php echo e(__('images')); ?></a>
                        </li>
                         <li class="nav-item">
                            <a href="/contact?language=<?php echo e(Request::get('language')); ?>" class="nav-link"><?php echo e(__('contact')); ?></a>
                        </li>
                        
                    </ul>
                </div>
        </nav>
    </div>
    <!-- navbar -->

    <!-- trinity -->
    <div class="trinity">
        <div class="container-fluid">
            <div class="row">
                <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-4 p-3">
                    <div class="Who-We-Are">
                        <h1><?php echo e(__('ktomi')); ?></h1>
                        <img src="../images/who we are.jpg" alt="Who-We-Are" class="img-fluid">
                        <h4 class="special-text"><?php echo e(__('ktomi2longtext')); ?></h4>
                        <h4><?php echo e(__('ktomi3longtext')); ?></h4>
                        <br><br>
                        
                    </div>
                </div>
                <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-4 p-3">
                    <h1><?php echo e(__('ktomi1')); ?></h1>
                    <ol>
                        <li><?php echo e(__('ktomi1text')); ?></li>
                        <h4><?php echo e(__('ktomi1longtext')); ?></h4>
                        <li><?php echo e(__('ktomi2text')); ?></li>
                        <h4><?php echo e(__('ktomi4longtext')); ?></h4>
                        <li><?php echo e(__('ktomi3text')); ?></li>
                        <h4><?php echo e(__('ktomi5longtext')); ?></h4>
                    </ol>
                </div>
                <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-4 p-3">
                    <h1><?php echo e(__('ktomi2')); ?></h1>
                    <h4><?php echo e(__('ktomi6longtext')); ?></h4>
                    <div class="primary-text">
                        <h3><?php echo e(__('ktomih1text')); ?></h3>
                        <h3><?php echo e(__('ktomih2text')); ?></h3>
                        <h3><?php echo e(__('ktomih3text')); ?></h3>
                        <h3><?php echo e(__('ktomih4text')); ?></h3>
                        <h3><?php echo e(__('ktomih5text')); ?></h3>
                        <h4><?php echo e(__('ktomi7longtext')); ?></h4>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- trinity -->

    <!-- Our Staff -->
    <div class="our-stuff">
        <div class="container-fluid">
            <h1><?php echo e(__('ourPersonality')); ?></h1>
            <div class="row">
                <div class="col-xxl-3 col-xl-3 col-lg-3 col-md-3 p-3" data-aos="fade-up" data-aos-easing="linear"
                    data-aos-duration="1500">
                    <img src="../images/Walter martins.jpg" alt="walter martins" style="width: 100%; height:264px;
                        class="img-fluid">
                    <h4><?php echo e(__('ourPersonality1')); ?></h4>
                    <h5><?php echo e(__('ourPersonality1work')); ?></h5>
                </div>
                <div class="col-xxl-3 col-xl-3 col-lg-3 col-md-3 p-3" data-aos="fade-down" data-aos-easing="linear"
                    data-aos-duration="1500">
                    <img src="../images/Bradley Grosh.jpg" alt="walter martins" style="width: 100%; height:264px;"
                        class="img-fluid">
                    <h4><?php echo e(__('ourPersonality2')); ?></h4>
                    <h5><?php echo e(__('ourPersonality2work')); ?> </h5>
                </div>
                <div class="col-xxl-3 col-xl-3 col-lg-3 col-md-3 p-3" data-aos="fade-up" data-aos-easing="linear"
                    data-aos-duration="1500">
                    <img src="../images/Andy Matters.jpg" alt="walter martins" style="width: 100%; height:264px;"
                        class="img-fluid">
                    <h4><?php echo e(__('ourPersonality3')); ?></h4>
                    <h5><?php echo e(__('ourPersonality3work')); ?></h5>
                </div>
                <div class="col-xxl-3 col-xl-3 col-lg-3 col-md-3 p-3" data-aos="fade-down" data-aos-easing="linear"
                    data-aos-duration="1500">
                    <img src="../images/man bek.jpg" alt="walter martins" style="width: 100%; height:264px;"
                        class="img-fluid">
                    <h4><?php echo e(__('ourPersonality4')); ?></h4>
                    <h5><?php echo e(__('ourPersonality4work')); ?></h5>
                </div>
            </div>
        </div>
    </div>
    <!-- Our Staff -->

    <!-- Features -->
    <div class="features" data-aos="fade-up" data-aos-easing="linear" data-aos-duration="1500">
        <div class="container-fluid">
            <div class="row">
                <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-4 px-2">
                    <h1><?php echo e(__('bottomName')); ?></h1>
                    <div class="details row">
                        <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-12 col-sm-2 col-2">
                            <i class="fas fa-users fa-5x"></i>
                        </div>
                        <div class="col-xxl-8 col-xl-8 col-lg-8 col-md-12 col-sm-10 col-10">
                            <h4><?php echo e(__('bottom3')); ?></h4>
                            <h5><?php echo e(__('bottom4')); ?></h5>
                        </div>
                    </div>
                    <div class="details row">
                        <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-12 col-sm-2 col-2">
                            <i class="fas fa-trophy fa-5x"></i>
                        </div>
                        <div class="col-xxl-8 col-xl-8 col-lg-8 col-md-12 col-sm-10 col-10">
                            <h4><?php echo e(__('bottom5')); ?></h4>
                            <h5><?php echo e(__('bottom6')); ?></h5>
                        </div>
                    </div>
                    <div class="details row">
                        <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-12 col-sm-2 col-2">
                            <i class="fas fa-thumbs-up fa-5x"></i>
                        </div>
                        <div class="col-xxl-8 col-xl-8 col-lg-8 col-md-12 col-sm-10 col-10">
                            <h4><?php echo e(__('bottom7')); ?></h4>
                            <h5><?php echo e(__('bottom8')); ?></h5>
                        </div>
                    </div>
                </div>
                <div class="col-xxl-3 col-xl-3 col-md-3 px-2">
                    <h1><?php echo e(__('bottom1')); ?></h1>
                    <div class="details">
                        <h5><?php echo e(__('bottom9')); ?></h5><br>
                        <h5><?php echo e(__('bottom10')); ?></h5>
                    </div>
                </div>
                <div class="col-xxl-5 col-xl-5 col-lg-5 col-md-5 px-2">
                    <h1><?php echo e(__('bottom2')); ?></h1>
                    <div class="details center-img">
                        <div class="row">
                            <div class="col-xxl-5 col-xl-5 col-lg-5 col-md-12 col-12 px-2">
                                <img src="../images/David Peters.jpg" alt="david" class="img-fluid pt-2">
                            </div>
                            <div class="col-xxl-7 col-xl-7col-lg-7 col-md-12 col-12 px-2">
                                <h5>«<?php echo e(__('bottom11')); ?> »</h5>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Features -->

    <!-- footer -->
    <footer>
        <div class="text-center">
            <h4><?php echo e(__('manzil')); ?> </h4>
            <h1>
                <span><?php echo e(__('phone')); ?>:</span> <a href="callto:+998909307218">+998 (90) 930 72 18</a><br>
                <span><?php echo e(__('phone')); ?>:</span> <a href="callto:+998909588172">+998 (90) 958 81 72</a>
            </h1>
            <p><?php echo e(__('workTime')); ?></p>
            <div class="icons">
                <a href="#" class="fab fa-facebook-f fa-2x"></a>
                <a href="#" class="fab fa-twitter fa-2x"></a>
                <a href="#" class="fab fa-google-plus-g fa-2x"></a>
                <a href="#" class="fab fa-instagram fa-2x"></a>
            </div>
            <h6>
                <span>RedFox © 2021. </span><a href="#"><?php echo e(__('siyosat')); ?></a>
            </h6>
        </div>
    </footer>
    <!-- footer -->

    
    <div class="body">
        <div class='phone'>
            <a href="tel:+998337730580" class="fas fa-phone fa-1x"></a>
        </div>
        <div class="circle1"></div>
        <div class="circle2"></div>
    </div>
    

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ" crossorigin="anonymous">
    </script>
    <!-- anime -->
    <script src="https://unpkg.com/aos@next/dist/aos.js"></script>
    <script>
        AOS.init();
    </script>
</body>

</html>
<?php /**PATH C:\OSPanel\domains\falcon-app\resources\views/front/aboutPage.blade.php ENDPATH**/ ?>