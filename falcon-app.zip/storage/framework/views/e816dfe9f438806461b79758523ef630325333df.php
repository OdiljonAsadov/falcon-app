
<?php $__env->startSection('content'); ?>
    <h1>Информация</h1>
    <a href="/information/add" class="btn btn-success" style="margin-right: 20px">Добавить категорию</a>
    

    <table class="table text-center">
        <tr>
            <th>ID</th>
            <th>Title Uz</th>
            <th>Title Ru</th>
            <th>Image_1</th>
            <th>Image_2</th>
            <th>Image_3</th>
            <th>Summernote_uz</th>
            <th>Summernote_ru</th>
           
        </tr>
        <?php $__currentLoopData = $info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($inf->id); ?></td>
                <td><?php echo e($inf->title_uz); ?></td>
                <td><?php echo e($inf->title_ru); ?></td>
                <td><img src="<?php echo e($inf->image_1); ?>" alt="" style="height: 120px; width: 150px;"></td>
                <td><img src="<?php echo e($inf->image_2); ?>" alt="" style="height: 120px; width: 150px;"></td>
                <td><img src="<?php echo e($inf->image_3); ?>" alt="" style="height: 120px; width: 150px;"></td>
                
                <td><?php echo $inf->summernote_uz; ?></td>
                <td><?php echo $inf->summernote_ru; ?></td>
                
               
                <td>
                    <a href="/information/edit/<?php echo e($inf->id); ?>" class="btn btn-success">Редактировать</a>
                    <a href="/information/show/<?php echo e($inf->id); ?>" class="btn btn-primary">show</a>
                    <a href="/information/delete/<?php echo e($inf->id); ?>" class="btn btn-danger">Удалить</a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\falcon-app\resources\views/information/index.blade.php ENDPATH**/ ?>